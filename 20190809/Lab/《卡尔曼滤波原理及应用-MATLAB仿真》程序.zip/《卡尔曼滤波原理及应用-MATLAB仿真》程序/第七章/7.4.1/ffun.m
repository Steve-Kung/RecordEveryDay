function Xnew=ffun(X)
Xnew(1,1)=X(1)+1;
Xnew(2,1)=X(2)+sin(0.1*X(1));