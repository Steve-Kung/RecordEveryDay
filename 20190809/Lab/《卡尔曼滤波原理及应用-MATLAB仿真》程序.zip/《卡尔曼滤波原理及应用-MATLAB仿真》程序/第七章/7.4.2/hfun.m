function d=hfun(X)
x0=0;y0=0;
d=sqrt( (X(1)-x0)^2+(X(2)-y0)^2 );